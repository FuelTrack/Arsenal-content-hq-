"""Fetch Arsenal headlines from public Google News RSS search results, stdlib only."""
import datetime as dt
import email.utils
import json
import pathlib
import re
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parents[1]
QUERIES = [
    ('Transfers', 'Arsenal FC transfer news'),
    ('Team news', 'Arsenal FC injury team news'),
    ('Matchday', 'Arsenal FC match preview result'),
    ('General', 'Arsenal FC football news'),
]

def fetch(category, query):
    url = 'https://news.google.com/rss/search?' + urllib.parse.urlencode({'q': query + ' when:3d', 'hl': 'en-GB', 'gl': 'GB', 'ceid': 'GB:en'})
    req = urllib.request.Request(url, headers={'User-Agent': 'ArsenalContentHQ/1.0 (RSS reader)'})
    with urllib.request.urlopen(req, timeout=25) as resp:
        tree = ET.fromstring(resp.read())
    items = []
    for item in tree.findall('./channel/item'):
        title = (item.findtext('title') or '').strip()
        link = (item.findtext('link') or '').strip()
        if not title or not link.startswith('https://'):
            continue
        source_node = item.find('source')
        source = source_node.text if source_node is not None and source_node.text else 'Google News'
        pub = item.findtext('pubDate')
        try:
            date = email.utils.parsedate_to_datetime(pub).astimezone(dt.timezone.utc).isoformat()
        except (ValueError, TypeError):
            date = None
        items.append({'title': re.sub(r'\s+', ' ', title), 'url': link, 'source': source, 'category': category, 'date': date})
    return items

def main():
    all_items = []
    for category, query in QUERIES:
        try:
            result = fetch(category, query)
            print(f'{category}: {len(result)} stories')
            all_items.extend(result)
        except Exception as exc:
            print(f'{category}: fetch failed: {exc}')
    seen, unique = set(), []
    for item in sorted(all_items, key=lambda x: x['date'] or '', reverse=True):
        key = re.sub(r'[^a-z0-9]+', '', item['title'].lower())
        if key not in seen:
            seen.add(key)
            unique.append(item)
    output = ROOT / 'data' / 'news.json'
    if not unique:
        print('No new articles; keeping existing feed.')
        return
    output.write_text(json.dumps({'updated_at': dt.datetime.now(dt.timezone.utc).isoformat(), 'articles': unique[:120]}, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Wrote {len(unique[:120])} stories')

if __name__ == '__main__':
    main()
