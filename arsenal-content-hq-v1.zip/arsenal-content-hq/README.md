# Arsenal Content HQ

A mobile-first, private-use editorial dashboard for @dailyarsenalinfo.

## What's included
- Categorised Arsenal news feed, search, source links, saved stories
- Instagram caption drafting and local saved drafts
- Post idea planner and editorial checklist
- Scheduled GitHub Actions RSS fetch every three hours (best effort)
- Static GitHub Pages-compatible hosting, no paid dependencies

## Run locally
Open `index.html` in a browser. News will show after you run `python scripts/fetch_news.py` and serve the directory using `python -m http.server 8000` (then open `http://localhost:8000`). Local `file://` mode may block JSON fetching.

## Deploy with GitHub Pages
1. Create a **new repository** and upload all the contents of this folder, preserving `.github/workflows/update-news.yml`.
2. Under **Settings → Pages**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`.
3. Under **Actions**, open **Update Arsenal news** and select **Run workflow** once.
4. The workflow then attempts to update the JSON feed every three hours. GitHub scheduled runs can be delayed, and the feed depends on third-party RSS availability.
5. If the workflow cannot push, check repository **Settings → Actions → General → Workflow permissions** and allow read/write access, if permitted.

## Privacy warning
**GitHub Pages is public even when the repository is private.** Do not store private credentials, unreleased material, or sensitive information in repository files. Drafts, saved articles and planner items are stored in browser localStorage and are not synced across devices. Anyone with the URL can load the app and use their own local workspace. Do not treat this as authenticated private access.

## Editorial and technical notes
- Feed entries are aggregated from Google News RSS search, and links may open Google News before the original publication. They are **not verified**.
- Source attribution is provided; read original stories and confirm claims before posting.
- The post studio is a **template generator**, not a paid AI integration. It does not invent factual context.
- Third-party RSS can change, rate-limit, or fail; the workflow preserves the previous feed if all sources fail.
- Google News links and articles remain owned by their respective publishers; do not republish copyrighted full articles or photos without permission.
- Future upgrade: login and cloud storage for genuinely private multi-device access.
